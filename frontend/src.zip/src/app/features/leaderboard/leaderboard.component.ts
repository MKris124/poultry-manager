import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnalyticsService } from '../../services/analytics.service';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';

@Component({
  selector: 'app-leaderboard',
  standalone: true,
  imports: [CommonModule, TableModule, ButtonModule],
  templateUrl: './leaderboard.component.html'
})
export class LeaderboardComponent implements OnInit {
  
  topLiver: any[] = [];
  topKosher: any[] = [];
  topMortality: any[] = [];

  constructor(private analyticsService: AnalyticsService) {}

  ngOnInit() {
    this.analyticsService.getLeaderboard().subscribe(data => {
      
      this.topLiver = [...data].sort((a, b) => b.avgLiverWeight - a.avgLiverWeight);

      this.topKosher = [...data].sort((a, b) => b.avgKosherPercent - a.avgKosherPercent);

      this.topMortality = [...data]
          .filter(d => d.avgMortalityRate !== null)
          .sort((a, b) => a.avgMortalityRate - b.avgMortalityRate);
    });
  }

  getMedal(index: number): string {
      if (index === 0) return '🥇';
      if (index === 1) return '🥈';
      if (index === 2) return '🥉';
      return (index + 1) + '.';
  }
}