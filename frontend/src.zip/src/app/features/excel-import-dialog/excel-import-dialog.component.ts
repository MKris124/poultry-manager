import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { FileUploadModule } from 'primeng/fileupload';
import { MessageService } from 'primeng/api';
import { ShipmentService } from '../../services/shipment.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-excel-import-dialog',
  standalone: true,
  imports: [CommonModule, DialogModule, FileUploadModule],
  templateUrl: './excel-import-dialog.component.html',
  // Fontos: A toast sortöréséhez stílust adhatunk, 
  // de a PrimeNG alapból kezeli a \n-t a 'detail'-ben, ha a white-space be van állítva CSS-ben.
})
export class ExcelImportDialogComponent {
  @Output() onClosed = new EventEmitter<void>();
  visible: boolean = false;
  isUploading: boolean = false;

  constructor(
    private messageService: MessageService,
    private shipmentService: ShipmentService
  ) {}

  show() {
    this.visible = true;
    this.isUploading = false;
  }

  uploadHandler(event: any) {
    if (event.files.length === 0) return;

    this.isUploading = true;
    const file = event.files[0];

    this.shipmentService.uploadExcel(file).subscribe({
      next: (response: any) => {
        this.isUploading = false;
        this.visible = false; // Bezárjuk az ablakot
        
        // Ellenőrizzük a választ
        if (response.failedCount > 0) {
            // Volt hiba, de volt ami sikerült?
            const severity = response.successCount > 0 ? 'warn' : 'error';
            const summary = response.successCount > 0 ? 'Részleges siker' : 'Importálási hiba';
            
            // Hibák összefűzése (max 5-öt jelenítünk meg, hogy ne lógjon le a képernyőről)
            let errorDetail = `Sikerült: ${response.successCount}, Hibás: ${response.failedCount}\n`;
            
            // Az első 5 hiba megjelenítése
            const errorsToShow = response.errorMessages.slice(0, 5);
            errorDetail += errorsToShow.join('\n');
            
            if (response.errorMessages.length > 5) {
                errorDetail += `\n...és további ${response.errorMessages.length - 5} hiba.`;
            }

            // Sticky (ragadós) üzenet, hogy el tudja olvasni
            this.messageService.add({
                severity: severity, 
                summary: summary, 
                detail: errorDetail, 
                life: 10000 // 10 másodpercig látszik
            });
        } else {
            // Minden sikerült
            this.messageService.add({
                severity: 'success', 
                summary: 'Siker', 
                detail: `${response.successCount} sor sikeresen importálva!`
            });
        }

        this.onClosed.emit();
      },
      error: (err: HttpErrorResponse) => {
        this.isUploading = false;
        console.error(err);
        
        // Ez akkor fut le, ha a szerver 500-as hibát dob (pl. adatbázis lehal), 
        // nem pedig validációs hibát az Excel sorokban.
        const msg = err.error?.message || 'Kritikus szerver hiba történt.';
        this.messageService.add({severity: 'error', summary: 'Hiba', detail: msg});
      }
    });
  }
}