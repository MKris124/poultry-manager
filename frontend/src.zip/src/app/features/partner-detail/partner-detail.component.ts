import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';

import { ShipmentService } from '../../services/shipment.service';
import { AnalyticsService } from '../../services/analytics.service';
import { TrendChartComponent } from '../trend-chart/trend-chart.component';

import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { MessageService, ConfirmationService } from 'primeng/api';
import { TooltipModule } from 'primeng/tooltip';
import { MultiSelectModule } from 'primeng/multiselect';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-partner-detail',
  standalone: true,
  imports: [
    CommonModule, FormsModule, TableModule, ButtonModule, 
    InputTextModule, ToastModule, TooltipModule, MultiSelectModule,
    ConfirmPopupModule, TrendChartComponent
  ],
  providers: [MessageService, ConfirmationService],
  templateUrl: './partner-detail.component.html'
})
export class PartnerDetailComponent implements OnChanges {
  @Input() partner: any;

  shipments: any[] = [];
  clonedShipments: { [s: string]: any } = {};
  selectedStats: any = null;
  isSaving: boolean = false;

  cols: any[] = [
    { field: 'deliveryCode', header: 'Kód' },
    { field: 'deliveryDate', header: 'Beszállítás' },
    { field: 'processingWeek', header: 'Hét' },
    { field: 'processingDate', header: 'Vágás' },
    { field: 'quantity', header: 'Befogott db' },
    { field: 'totalWeight', header: 'Befogott kg' },
    { field: 'avgWeight', header: 'Átlag kg' },
    { field: 'netQuantity', header: 'Beszállított db' },
    { field: 'netWeight', header: 'Beszállított kg' },
    { field: 'netAvgWeight', header: 'Leadott átl. kg' },
    { field: 'transportMortality', header: 'Útihulla db' },
    { field: 'transportMortalityKg', header: 'Útihulla kg' },
    { field: 'liverWeight', header: 'Máj' },
    { field: 'kosherPercent', header: 'Kóser %' },
    { field: 'fatteningRate', header: 'Ráhízás' },
    { field: 'fatteningDays', header: 'Tömés nap' },
    { field: 'mortalityCount', header: 'Elhullás' },
    { field: 'mortalityRate', header: 'Elhullás %' }
  ];
  _selectedColumns: any[] = [];

  constructor(
    private shipmentService: ShipmentService,
    private analyticsService: AnalyticsService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService
  ) {}

  get selectedColumns(): any[] { return this._selectedColumns; }
  set selectedColumns(val: any[]) { this._selectedColumns = val; }
  get hasUnsavedChanges(): boolean { return this.shipments.some(ship => this.isRowChanged(ship)); }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['partner'] && this.partner) {
      this._selectedColumns = this.cols;
      this.loadData();
    }
  }

  loadData() {
    this.shipments = [];
    this.clonedShipments = {};
    this.selectedStats = null;

    if (this.partner.isGroup) {
        this.shipmentService.getHistoryByPartners(this.partner.ids).subscribe(data => {
            this.processShipmentData(data);
            this.calculateGroupStats();
        });

    } else {
        this.shipmentService.getHistoryByPartner(this.partner.id).subscribe(data => {
            this.processShipmentData(data);
        });
        
        this.analyticsService.getPartnerStats(this.partner.id).subscribe(s => this.selectedStats = s);
    }
  }

  processShipmentData(data: any[]) {
      this.shipments = data.map(ship => {
        const avg = ship.quantity > 0 ? (ship.totalWeight / ship.quantity) : 0;
        return { ...ship, avgWeight: avg };
      });
      this.shipments.forEach(s => this.clonedShipments[s.id] = { ...s });
  }

  calculateGroupStats() {
      let sumLiver = 0, countLiver = 0;
      let sumKosher = 0, countKosher = 0;
      let sumFattening = 0, countFattening = 0;
      let sumMortalityRate = 0, countMortalityRate = 0;

      this.shipments.forEach(s => {
          if (s.liverWeight != null) { sumLiver += s.liverWeight; countLiver++; }
          if (s.kosherPercent != null) { sumKosher += s.kosherPercent; countKosher++; }
          if (s.fatteningRate != null) { sumFattening += s.fatteningRate; countFattening++; }
          if (s.mortalityRate != null) { sumMortalityRate += s.mortalityRate; countMortalityRate++; }
      });

      this.selectedStats = {
          avgLiverWeight: countLiver ? (sumLiver / countLiver) : 0,
          avgKosherPercent: countKosher ? (sumKosher / countKosher) : 0,
          avgFatteningRate: countFattening ? (sumFattening / countFattening) : 0,
          avgMortalityRate: countMortalityRate ? (sumMortalityRate / countMortalityRate) : 0
      };
  }

  saveAll() {
    const changedShips = this.shipments.filter(ship => this.isRowChanged(ship));
    if (changedShips.length === 0) return;

    // VALIDÁCIÓ: Ha nincs kitöltve a DeliveryCode, hibaüzenet
    const invalidShip = changedShips.find(s => !s.deliveryCode || s.deliveryCode.trim() === '');
    if (invalidShip) {
        this.messageService.add({
            severity: 'error', 
            summary: 'Hiányzó adat', 
            detail: 'A Kód mező kitöltése kötelező minden sornál!'
        });
        return; // MEGÁLLÍTJUK A MENTÉST
    }

    this.isSaving = true;
    const observables = [];

    for (const ship of changedShips) {
        let formattedDate = ship.deliveryDate;
        if (typeof ship.deliveryDate === 'object' && ship.deliveryDate !== null) {
            const d = ship.deliveryDate;
            const offset = d.getTimezoneOffset() * 60000;
            formattedDate = new Date(d.getTime() - offset).toISOString().split('T')[0];
        }

        // --- UPDATE JAVÍTÁS ---
        // Kiszámoljuk a Netto db-ot (Befogott - Elhullás)
        const currentNetQty = (ship.quantity || 0) - (ship.mortalityCount || 0);

        const dto = { 
            ...ship, 
            partnerId: ship.partnerId || this.partner.id,
            deliveryDate: formattedDate,
            
            // Beállítjuk a helyes beszállított darabszámot
            netQuantity: currentNetQty,

            // FONTOS: Nullázzuk a számított mezőket, hogy a Backend
            // a friss súlyok alapján számolja újra őket!
            fatteningRate: null, 
            mortalityRate: null 
        };

        if (!ship.id) {
            observables.push(this.shipmentService.createShipment(dto));
        } else {
            observables.push(this.shipmentService.updateShipment(ship.id, dto));
        }
    }

    forkJoin(observables).subscribe({
    next: (results) => {
         this.messageService.add({severity:'success', summary:'Siker', detail: 'Sikeres mentés.'});
         this.loadData();
         this.isSaving = false;
    },
    error: (err: HttpErrorResponse) => {
        this.isSaving = false;
        console.log('Teljes hiba objektum:', err); 
        let userMessage = 'Hiba történt a mentés során.';

        if (err.error && err.error.message) {
            userMessage = err.error.message;
        } else if (typeof err.error === 'string') {
            userMessage = err.error;
        } else {
            userMessage = err.message;
        }

        this.messageService.add({
            severity: 'error', 
            summary: 'Hiba', 
            detail: userMessage, 
            life: 8000 
        });
    }
    });
  }

  deleteShipment(event: Event, ship: any) {
    this.confirmationService.confirm({
        target: event.target as EventTarget,
        message: 'Biztosan törölni szeretnéd ezt a sort?',
        icon: 'pi pi-exclamation-triangle',
        acceptLabel: 'Igen',
        rejectLabel: 'Nem',
        accept: () => {
            this.shipmentService.deleteShipment(ship.id).subscribe({
                next: () => {
                    this.messageService.add({ severity: 'success', summary: 'Törölve', detail: 'Sikeres törlés.' });
                    this.loadData();
                },
                error: () => this.messageService.add({ severity: 'error', summary: 'Hiba' })
            });
        }
    });
  }

  addEmptyRow() {
    if (this.partner.isGroup) {
        this.messageService.add({severity:'warn', summary:'Figyelem', detail:'Csoportos nézetben nem lehet új sort felvenni.'});
        return;
    }

    const newRow = {
      partnerId: this.partner.id, deliveryCode: '', deliveryDate: new Date().toISOString().split('T')[0],
      processingDate: null, quantity: 0, totalWeight: 0, avgWeight: 0, liverWeight: 0,
      kosherPercent: 0, fatteningRate: 0, mortalityCount: 0, mortalityRate: 0
    };
    this.shipments = [newRow, ...this.shipments];
  }

  revertAll() { this.loadData(); this.messageService.add({severity:'info', summary:'Visszavonva'}); }

  onRowCancel(ship: any, index: number) {
    if (!ship.id) this.shipments.splice(index, 1);
    else this.shipments[index] = { ...this.clonedShipments[ship.id] };
  }

  isRowChanged(ship: any): boolean {
    if (!ship.id) return true;
    const original = this.clonedShipments[ship.id];
    if (!original) return false;

    // --- CHANGE DETECTION JAVÍTÁS ---
    // Kivesszük az összehasonlításból a számított mezőket, 
    // hogy a UI kerekítések ne okozzanak fals "változást".
    const keysToIgnore = ['avgWeight', 'netAvgWeight', 'fatteningRate', 'mortalityRate', 'netQuantity'];

    const shipProps = { ...ship };
    const origProps = { ...original };

    keysToIgnore.forEach(key => {
        delete shipProps[key];
        delete origProps[key];
    });
    
    // Dátum normalizálás
    if (shipProps.deliveryDate instanceof Date) {
        const d = shipProps.deliveryDate;
        const offset = d.getTimezoneOffset() * 60000;
        shipProps.deliveryDate = new Date(d.getTime() - offset).toISOString().split('T')[0];
    }

    return JSON.stringify(shipProps) !== JSON.stringify(origProps);
  }

  recalculateAvg(ship: any) {
    ship.avgWeight = ship.quantity > 0 ? (ship.totalWeight / ship.quantity) : 0;
  }

  isColVisible(field: string): boolean { return this._selectedColumns.some(c => c.field === field); }
  getLiverColor(val: number): string { return !val ? '' : (val >= 0.6 ? 'text-green-500' : 'text-yellow-500'); }
  getKosherColor(val: number): string { return !val ? '' : (val >= 60 ? 'text-green-500' : 'text-yellow-500'); }
}